package application.controllers;

import javafx.fxml.FXMLLoader;

import java.io.IOException;

import application.DatabaseConnection;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SampleController {

    @FXML
    private Button button_sign;

    @FXML
    private TextField field_login;

    @FXML
    private TextField field_password;

    @FXML
    private Label label_message;

    @FXML
    void button_sign_click(ActionEvent event) {
        String login = field_login.getText();
        String password = field_password.getText();

        if (DatabaseConnection.checkLogin(login, password)) {
            openDashboard();
        } else {
            label_message.setText("Invalid username or password.");
        }
    }

    private void openDashboard() {
    	
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/pages/mainPage.fxml"));
            Parent root = loader.load();
            Stage dashboardStage = new Stage();
            dashboardStage.setScene(new Scene(root));
            dashboardStage.show();

            // Закрыть текущее окно (по желанию)
            Stage currentStage = (Stage) button_sign.getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void initialize() {
        assert button_sign != null : "fx:id=\"button_sign\" was not injected: check your FXML file 'main.fxml'.";
        assert field_login != null : "fx:id=\"field_login\" was not injected: check your FXML file 'main.fxml'.";
        assert field_password != null : "fx:id=\"field_password\" was not injected: check your FXML file 'main.fxml'.";
        assert label_message != null : "fx:id=\"label_message\" was not injected: check your FXML file 'main.fxml'.";
    }
}