package application.models;

public class Material {
    private int id;
    private String title;
    private String category;
    private int price;
    private int countMaterials;
    private int minCount;
    private int countInPackage;
    private String unit;
    
    
	public Material(int id, String title, String category, int price, int countMaterials, int minCount,
			int countInPackage, String unit) {
		super();
		this.id = id;
		this.title = title;
		this.category = category;
		this.price = price;
		this.countMaterials = countMaterials;
		this.minCount = minCount;
		this.countInPackage = countInPackage;
		this.unit = unit;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getCountMaterials() {
		return countMaterials;
	}
	public void setCountMaterials(int countMaterials) {
		this.countMaterials = countMaterials;
	}
	public int getMinCount() {
		return minCount;
	}
	public void setMinCount(int minCount) {
		this.minCount = minCount;
	}
	public int getCountInPackage() {
		return countInPackage;
	}
	public void setCountInPackage(int countInPackage) {
		this.countInPackage = countInPackage;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
}
