package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import application.models.Material;

public class DatabaseConnection {
    private static String url = "jdbc:mysql://localhost:3306/qe";
    private static String username = "root";
    private static String password = "root";
    private static Connection conn;

    public static void reconnect() {
        try {
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("DATABASE: connect");
        } catch (Exception ex) {
            System.out.println("DATABASE: discowdqwdnnect");
            ex.printStackTrace();
        }
    }

    public static boolean checkLogin(String user, String pass) {
        String query = "SELECT * FROM user WHERE login = ? AND password = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, user);
            stmt.setString(2, pass);
            
            ResultSet rs = stmt.executeQuery();
            return rs.next();
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}