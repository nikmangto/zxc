module demoEx {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
	requires javafx.graphics;

    opens application.controllers to javafx.fxml; // Open controllers package to javafx.fxml
    opens application to javafx.graphics, javafx.fxml;
}
