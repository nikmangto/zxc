package application.controllers;

public class MainPageController {

}
